rm -f assignment4.zip
zip -r assignment4.zip * 