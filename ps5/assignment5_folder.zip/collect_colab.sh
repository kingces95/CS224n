rm -f assignment5_folder.zip
zip -r assignment5_folder.zip *
